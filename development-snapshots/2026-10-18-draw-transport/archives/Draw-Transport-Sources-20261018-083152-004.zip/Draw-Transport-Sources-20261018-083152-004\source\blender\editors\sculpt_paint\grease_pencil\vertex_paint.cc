/* SPDX-FileCopyrightText: 2024 Blender Authors
 *
 * SPDX-License-Identifier: GPL-2.0-or-later */

#include "BLI_color.hh"
#include "BLI_color_mix.hh"
#include "BLI_math_color.hh"

#include "DNA_brush_types.h"

#include "BKE_brush.hh"
#include "BKE_context.hh"
#include "BKE_curves.hh"
#include "BKE_grease_pencil.hh"
#include "BKE_paint.hh"

#include "grease_pencil_intern.hh"

namespace blender::ed::sculpt_paint::greasepencil {

class VertexPaintOperation : public GreasePencilStrokeOperationCommon {
  using GreasePencilStrokeOperationCommon::GreasePencilStrokeOperationCommon;

 public:
  void on_stroke_begin(const bContext &C, const InputSample &start_sample) override;
  void on_stroke_extended(const bContext &C, const InputSample &extension_sample) override;
  void on_stroke_done(const bContext & /*C*/) override {}
};

void VertexPaintOperation::on_stroke_begin(const bContext &C, const InputSample &start_sample)
{
  this->init_stroke(C, start_sample);
  this->on_stroke_extended(C, start_sample);
}

void VertexPaintOperation::on_stroke_extended(const bContext &C,
                                              const InputSample &extension_sample)
{
  const Scene &scene = *CTX_data_scene(&C);
  Paint &paint = *BKE_paint_get_active_from_context(&C);
  const Brush &brush = *BKE_paint_brush(&paint);
  const bool invert = this->is_inverted(brush);

  const IMB_BlendMode blend_mode = IMB_BlendMode(brush.blend);

  const bool use_selection_masking = ED_grease_pencil_any_vertex_mask_selection(
      scene.toolsettings);

  const bool do_points = do_vertex_color_points(brush);
  const bool do_fill = do_vertex_color_fill(brush);

  float color_linear[3];
  copy_v3_v3(color_linear, BKE_brush_color_get(&paint, &brush));
  const ColorPaint4f mix_color(color_linear[0], color_linear[1], color_linear[2], 1.0f);

  this->foreach_editable_drawing(C, [&](const GreasePencilStrokeParams &params) {
    IndexMaskMemory memory;
    const IndexMask point_selection = point_mask_for_stroke_operation(
        params, use_selection_masking, memory);
    if (!point_selection.is_empty() && do_points) {
      const Array<float2> view_positions = view_positions_from_point_mask(params, point_selection);
      MutableSpan<ColorGeometry4f> vertex_colors = params.drawing.vertex_colors_for_write();

      if (invert) {
        /* Erase vertex colors. */
        point_selection.foreach_index(
            [&](const int64_t point_i) {
              const float influence = brush_point_influence(paint,
                                                            brush,
                                                            view_positions[point_i],
                                                            extension_sample,
                                                            params.multi_frame_falloff);

              ColorGeometry4f &color = vertex_colors[point_i];
              color.a -= influence;
              color.a = math::max(color.a, 0.0f);
            },
            exec_mode::grain_size(4096));
      }
      else {
        /* Mix brush color into vertex colors by influence. */
        point_selection.foreach_index(
            [&](const int64_t point_i) {
              const float influence = brush_point_influence(paint,
                                                            brush,
                                                            view_positions[point_i],
                                                            extension_sample,
                                                            params.multi_frame_falloff);

              ColorGeometry4f &color = vertex_colors[point_i];

              using Color = ColorPaint4f;
              using Traits = color::Traits<Color>;

              const Color linearrgb_color = color::unpremultiply_alpha(color);

              color = color::premultiply_alpha(color::BLI_mix_colors<Color, Traits>(
                  blend_mode, linearrgb_color, mix_color, Traits::range * influence));
            },
            exec_mode::grain_size(4096));
      }
    }

    const IndexMask fill_selection = fill_mask_for_stroke_operation(
        params, use_selection_masking, memory);
    if (!fill_selection.is_empty() && do_fill) {
      BLI_assert(params.drawing.fills().has_value());
      const GroupedSpan<int> fills = *params.drawing.fills();
      const bke::CurvesGeometry &curves = params.drawing.strokes();
      const OffsetIndices<int> points_by_curve = curves.points_by_curve();
      MutableSpan<ColorGeometry4f> fill_colors = params.drawing.fill_colors_for_write();
      /* TODO. Only calculate needed positions. */
      const Array<float2> view_positions = view_positions_from_curve_mask(params,
                                                                          curves.curves_range());

      if (invert) {
        fill_selection.foreach_index(
            [&](const int64_t fill_i) {
              const Span<int> fill_curves = fills[fill_i];
              const IndexMask fill_curve_mask = IndexMask::from_indices(fill_curves, memory);

              float influence = 0.0f;
              fill_curve_mask.foreach_index([&](const int64_t curve) {
                const IndexRange points = points_by_curve[curve];
                const Span<float2> curve_view_positions = view_positions.as_span().slice(points);
                influence = math::max(influence,
                                      brush_fill_influence(paint,
                                                           brush,
                                                           curve_view_positions,
                                                           extension_sample,
                                                           params.multi_frame_falloff));
              });

              ColorGeometry4f color = fill_colors[fill_curves.first()];
              color.a -= influence;
              color.a = math::max(color.a, 0.0f);

              index_mask::masked_fill(fill_colors, color, fill_curve_mask);
            },
            exec_mode::grain_size(1024));
      }
      else {
        fill_selection.foreach_index(
            [&](const int64_t fill_i) {
              const Span<int> fill_curves = fills[fill_i];
              const IndexMask fill_curve_mask = IndexMask::from_indices(fill_curves, memory);

              float influence = 0.0f;
              fill_curve_mask.foreach_index([&](const int64_t curve) {
                const IndexRange points = points_by_curve[curve];
                const Span<float2> curve_view_positions = view_positions.as_span().slice(points);
                influence = math::max(influence,
                                      brush_fill_influence(paint,
                                                           brush,
                                                           curve_view_positions,
                                                           extension_sample,
                                                           params.multi_frame_falloff));
              });

              ColorGeometry4f color = fill_colors[fill_curves.first()];

              using Color = ColorPaint4f;
              using Traits = color::Traits<Color>;

              const Color linearrgb_color = color::unpremultiply_alpha(color);

              color = color::premultiply_alpha(color::BLI_mix_colors<Color, Traits>(
                  blend_mode, linearrgb_color, mix_color, Traits::range * influence));

              index_mask::masked_fill(fill_colors, color, fill_curve_mask);
            },
            exec_mode::grain_size(1024));
      }
    }

    return true;
  });
}

std::unique_ptr<GreasePencilStrokeOperation> new_vertex_paint_operation(
    const BrushStrokeMode stroke_mode)
{
  return std::make_unique<VertexPaintOperation>(stroke_mode);
}

}  // namespace blender::ed::sculpt_paint::greasepencil
