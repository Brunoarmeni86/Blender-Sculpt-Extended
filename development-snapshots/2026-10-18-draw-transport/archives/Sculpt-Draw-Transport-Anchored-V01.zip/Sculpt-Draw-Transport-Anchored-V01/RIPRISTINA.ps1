$ErrorActionPreference = 'Stop'
if (Get-Process -Name blender -ErrorAction SilentlyContinue) { throw 'Chiudi Blender prima del ripristino.' }
$info = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ultima-applicazione.json') -Raw | ConvertFrom-Json
$state = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH-STATE.json') -Raw | ConvertFrom-Json
$target = Join-Path $info.SourceRoot $state.file
$header = Join-Path $info.SourceRoot $state.header
if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $state.after_sha256) { throw 'sculpt.cc modificato dopo la patch: ripristino automatico interrotto.' }
if (!(Test-Path -LiteralPath $header) -or (Get-FileHash -LiteralPath $header -Algorithm SHA256).Hash -ne $state.payload_hashes.'sculpt_draw_transport_v01.hh') { throw 'Header mancante o modificato: ripristino automatico interrotto.' }
$original = Join-Path $info.Backup 'sculpt.cc'
if ((Get-FileHash -LiteralPath $original -Algorithm SHA256).Hash -ne $state.before_sha256) { throw 'Backup sorgente non corrispondente.' }
Copy-Item -LiteralPath $original -Destination $target -Force
Remove-Item -LiteralPath $header
$oldExe = Join-Path $info.Backup 'blender.exe'
if (Test-Path -LiteralPath $oldExe) { Copy-Item -LiteralPath $oldExe -Destination (Join-Path $info.BuildRoot 'bin\Release\blender.exe') -Force }
Write-Host 'Sorgente precedente ripristinato; eseguibile ripristinato se presente nel backup.' -ForegroundColor Green
