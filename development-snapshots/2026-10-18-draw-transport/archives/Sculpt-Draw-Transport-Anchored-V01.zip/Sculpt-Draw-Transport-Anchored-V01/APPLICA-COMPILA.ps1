param(
    [string]$SourceRoot = 'C:\BlenderDev\blender',
    [string]$BuildRoot = 'C:\BlenderDev\build_windows_x64_shareable',
    [ValidateRange(1,64)][int]$Parallel = 4
)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name blender -ErrorAction SilentlyContinue) { throw 'Chiudi Blender prima della patch.' }
$state = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH-STATE.json') -Raw | ConvertFrom-Json
$target = Join-Path $SourceRoot $state.file
$header = Join-Path $SourceRoot $state.header
if (!(Test-Path -LiteralPath $target)) { throw "Sorgente mancante: $target" }
$current = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
if ($current -eq $state.after_sha256) { throw 'Patch gia applicata. Usa COMPILA.ps1 oppure verifica la cartella backup.' }
if ($current -ne $state.before_sha256) { throw 'sculpt.cc diverso dai sorgenti ricevuti: patch non applicata.' }
if (Test-Path -LiteralPath $header) { throw 'Header Draw Transport gia presente: nessuna sovrascrittura.' }
foreach ($name in @('sculpt.cc','sculpt_draw_transport_v01.hh')) {
    $payload = Join-Path $PSScriptRoot "payload\$name"
    $expected = $state.payload_hashes.$name
    if (!$expected -or (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash -ne $expected) { throw "Payload non valido: $name" }
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$backup = Join-Path $PSScriptRoot "backup-$stamp"
New-Item -ItemType Directory -Path $backup | Out-Null
Copy-Item -LiteralPath $target -Destination (Join-Path $backup 'sculpt.cc')
$exe = Join-Path $BuildRoot 'bin\Release\blender.exe'
if (Test-Path -LiteralPath $exe) { Copy-Item -LiteralPath $exe -Destination (Join-Path $backup 'blender.exe') }
@{ SourceRoot=$SourceRoot; BuildRoot=$BuildRoot; Backup=$backup; HeaderWasAbsent=$true } |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'ultima-applicazione.json') -Encoding UTF8
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'payload\sculpt_draw_transport_v01.hh') -Destination $header
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'payload\sculpt.cc') -Destination $target
Write-Host "Patch applicata. Backup: $backup" -ForegroundColor Green
& (Join-Path $PSScriptRoot 'COMPILA.ps1') -BuildRoot $BuildRoot -Parallel $Parallel
