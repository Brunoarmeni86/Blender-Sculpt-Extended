"""Session UI for native Draw Transport V02. No native mutation from Python."""
import bpy


def transport_update(brush, context):
    if brush.sculpt_draw_transport_v01:
        if brush.sculpt_brush_type != 'DRAW':
            brush.sculpt_draw_transport_v01 = False
            return
        brush.stroke_method = 'ANCHORED'
        brush.use_edge_to_edge = False


class VIEW3D_PT_draw_transport_v01(bpy.types.Panel):
    bl_label = 'Draw Transport V02'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Multires'

    @classmethod
    def poll(cls, context):
        return context.mode == 'SCULPT' and context.tool_settings.sculpt is not None

    def draw(self, context):
        layout = self.layout
        brush = context.tool_settings.sculpt.brush
        if brush is None:
            layout.label(text='Seleziona un pennello Draw')
            return
        if brush.sculpt_brush_type != 'DRAW':
            layout.label(text='Seleziona Draw per usare Transport', icon='INFO')
            return
        layout.prop(brush, 'sculpt_draw_transport_v01', text='Draw Transport Anchored')
        layout.label(text='Trascina: raggio e orientamento')
        layout.label(text='Rilascia, poi muovi: trasporta')
        layout.label(text='R: ruota attorno al centro')
        layout.label(text='Clic / Invio: accetta angolo o conferma')
        layout.label(text='Esc / destro: annulla lo stroke')
        layout.separator()
        layout.label(text='V01: Multires massimo; simmetrie OFF')
        layout.label(text='REC attivo se usi Sculpt Layers')


if bpy.ops.sculpt.brush_stroke.get_rna_type().properties.get('draw_transport') is None:
    raise RuntimeError('Draw Transport V02: eseguibile non ricompilato con la patch')

old = getattr(bpy.types, 'VIEW3D_PT_draw_transport_v01', None)
if old is not None:
    bpy.utils.unregister_class(old)
if not hasattr(bpy.types.Brush, 'sculpt_draw_transport_v01'):
    bpy.types.Brush.sculpt_draw_transport_v01 = bpy.props.BoolProperty(
        name='Draw Transport Anchored', default=False, update=transport_update,
        description='Mantiene lo stroke Draw Anchored riposizionabile dopo il rilascio')
bpy.utils.register_class(VIEW3D_PT_draw_transport_v01)
print('[DRAW_TRANSPORT_V02] UI pronta: N > Multires > Draw Transport V02', flush=True)
