param([string]$BuildRoot = 'C:\BlenderDev\build_windows_x64_shareable', [ValidateRange(1,64)][int]$Parallel = 4)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name blender -ErrorAction SilentlyContinue) { throw 'Chiudi Blender prima della build.' }
if (!(Test-Path -LiteralPath (Join-Path $BuildRoot 'CMakeCache.txt'))) { throw "Build non configurata: $BuildRoot" }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$log = Join-Path $PSScriptRoot "build-draw-transport-$stamp.log"
$savedErrorPreference = $ErrorActionPreference
try {
    $ErrorActionPreference = 'Continue'
    & cmake --build $BuildRoot --config Release --parallel $Parallel 2>&1 | Tee-Object -FilePath $log
    $code = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $savedErrorPreference
}
Write-Host "Log build: $log"
if ($code -ne 0) { throw "Build fallita ($code). Carica il log; sorgenti precedenti nel backup." }
Write-Host 'BUILD COMPLETATA. Avvia AVVIA.ps1 per la prova.' -ForegroundColor Green
