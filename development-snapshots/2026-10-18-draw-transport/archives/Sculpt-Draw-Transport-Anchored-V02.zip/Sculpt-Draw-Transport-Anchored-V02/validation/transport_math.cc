
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <iostream>
#include <random>
struct float3 {
 union { struct {float x,y,z;}; float data[3];};
 float3(float a=0):x(a),y(a),z(a){}
 float3(float a,float b,float c):x(a),y(b),z(c){}
 float3 operator+(float3 b)const{return {x+b.x,y+b.y,z+b.z};}
 float3 operator-(float3 b)const{return {x-b.x,y-b.y,z-b.z};}
 float3 operator/(float f)const{return {x/f,y/f,z/f};}
};
float3 operator*(float f,float3 a){return {f*a.x,f*a.y,f*a.z};}
namespace math {
float dot(float3 a,float3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
float3 cross(float3 a,float3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
float length_squared(float3 a){return dot(a,a);}
float3 normalize(float3 a){float d=std::sqrt(dot(a,a));return d?a/d:float3(0);}
}
struct Triangle {std::array<float3,3> co,delta,normal;};
inline bool finite(const float3 &p)
{
  return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z);
}
inline float3 rotate(const float3 &v, const float3 &from, const float3 &to)
{
  const float c = std::clamp(math::dot(from, to), -1.0f, 1.0f);
  if (c > 0.999999f) { return v; }
  if (c < -0.9999f) {
    float3 axis = math::cross(from, float3(1, 0, 0));
    if (math::length_squared(axis) < 1e-8f) { axis = math::cross(from, float3(0, 1, 0)); }
    axis = math::normalize(axis);
    return 2.0f * math::dot(axis, v) * axis - v;
  }
  const float3 axis = math::normalize(math::cross(from, to));
  const float sine = std::sqrt(std::max(0.0f,1.0f-c*c));
  return c*v + sine*math::cross(axis,v) + (1.0f-c)*math::dot(axis,v)*axis;
}
inline float3 rotate_axis(const float3 &v, const float3 &axis, const float angle)
{
  const float cosine = std::cos(angle), sine = std::sin(angle);
  return cosine*v + sine*math::cross(axis,v) + (1.0f-cosine)*math::dot(axis,v)*axis;
}
inline bool weights(const Triangle &tri, const float3 &p, float3 &w)
{
  const float3 a = tri.co[1]-tri.co[0], b = tri.co[2]-tri.co[0], q = p-tri.co[0];
  const double aa = math::dot(a,a), ab = math::dot(a,b), bb = math::dot(b,b);
  const double aq = math::dot(a,q), bq = math::dot(b,q), det = aa*bb-ab*ab;
  if (det <= 1e-14*std::max(aa,bb)*std::max(aa,bb) || !std::isfinite(det)) { return false; }
  w.y = float((bb*aq-ab*bq)/det); w.z = float((aa*bq-ab*aq)/det); w.x = 1-w.y-w.z;
  return finite(w);
}

int main(){
 std::mt19937 rng(42);std::uniform_real_distribution<float>d(-1,1);
 float worst=0;
 for(int i=0;i<100000;i++){
  float3 a=math::normalize({d(rng),d(rng),d(rng)}),b=math::normalize({d(rng),d(rng),d(rng)});
  float3 v={d(rng),d(rng),d(rng)};
  float3 out=rotate(v,a,b);
  assert(finite(out));
  float err=std::abs(math::length_squared(out)-math::length_squared(v));worst=std::max(worst,err);
  assert(err<1e-5f);
  float3 mapped=rotate(a,a,b);
  assert(math::length_squared(mapped-b)<.00025f);
 }
 for(int i=0;i<10000;i++){
  float3 axis=math::normalize({d(rng),d(rng),d(rng)}),v={d(rng),d(rng),d(rng)};
  float angle=d(rng)*6.2831853f;
  float3 turned=rotate_axis(v,axis,angle),back=rotate_axis(turned,axis,-angle);
  assert(finite(turned));
  assert(std::abs(math::length_squared(turned)-math::length_squared(v))<1e-5f);
  assert(math::length_squared(back-v)<1e-10f);
  assert(std::abs(math::dot(turned,axis)-math::dot(v,axis))<2e-6f);
 }
 float3 quarter=rotate_axis({1,0,0},{0,0,1},1.57079632679f);
 assert(math::length_squared(quarter-float3(0,1,0))<1e-12f);
 // Forward stamp placement and inverse lookup must agree at a known triangle point.
 float3 placed=rotate_axis({.2f,.3f,0},{0,0,1},1.57079632679f);
 float3 recovered=rotate_axis(placed,{0,0,1},-1.57079632679f);
 assert(math::length_squared(recovered-float3(.2f,.3f,0))<1e-12f);
 Triangle t;t.co={float3(0,0,0),float3(1,0,0),float3(0,1,0)};
 float3 w;
 assert(weights(t,{.2f,.3f,0},w));
 assert(std::abs(w.x-.5f)<1e-6f && std::abs(w.y-.2f)<1e-6f && std::abs(w.z-.3f)<1e-6f);
 assert(std::abs(w.x*1+w.y*2+w.z*4-2.1f)<1e-6f);
 t.co={float3(0),float3(0),float3(0)};assert(!weights(t,float3(0),w));
 float3 flip=rotate({1,2,3},{0,0,1},{0,0,-1});
 assert(finite(flip)&&std::abs(math::length_squared(flip)-14)<1e-5f);
 std::cout<<"PASS: 100000 normal rotations + 10000 stamp rotations, 90-degree placement/inverse lookup, normal alignment, norm preservation, barycentric interpolation, degenerate rejection; max norm-squared error="<<worst<<"\n";
}
